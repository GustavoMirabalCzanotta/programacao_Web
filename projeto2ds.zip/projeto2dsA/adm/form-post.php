<!doctype html>
<html lang="pt_BR">
	<head>
	    <meta charset="UTF-8" />
		<title>Formulário</title>
	</head>
	<body>
		<div>
			<h1>Post</h1>
			<form method="POST">
				<p>
					Título: <input type="text" name="Título"/>
				</p>
				<p>
					Subtítulo: <input type="text" name="Subtítulo"/>
				</p>
				<p>
					Imagem: <input type="file" name="Imagem"/>
				</p>
				<p>
					Conteúdo:<br/>
					<textarea cols="20" rows="5"></textarea>
                </p>
				<p>
					<input type="submit" value="Incluir"> 
				</p>
			</form>
		<div>
	</body>
</html>