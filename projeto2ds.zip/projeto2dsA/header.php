<!DOCTYPE html>
<html lang="pt-br">
	<head>
	
		<meta charset="UTF-8" />
		<title>2ºDS - Criação de Websites</title>
		<link rel="stylesheet" type="text/css" href="css/estilo.css" />
		
	</head>
	<body>
	<div id="container">
	<div id="topo">
	<header><img src="img/logo.png">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php?pag=servicos">Serviços</a></li>
				<li><a href="index.php?pag=portfolio">Portifolio</a></li>
				<li><a href="index.php?pag=novidades">Novidades</a></li>
				<li><a href="index.php?pag=contato">Contato</a></li>
			</ul>
		
		</nav>
	</header>
	</div>
	<main>