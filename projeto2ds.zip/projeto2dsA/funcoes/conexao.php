<?php

function conexao($banco, $servidor="localhost", $usuario="root", $senha=""){
	$conexao = mysqli_connect()$servidor, $usuario, $senha, $banco);
		
	if(mysqli_connect_error()){
		printf("erro de conexao: %s", mysqli_connect_error());
		return false;
	
	}else{
		return $conexao;
	}
}