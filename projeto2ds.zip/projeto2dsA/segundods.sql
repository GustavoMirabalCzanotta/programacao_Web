-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25-Out-2021 às 16:26
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `segundods`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_login`
--

CREATE TABLE `tbl_login` (
  `log_id` int(11) NOT NULL,
  `log_login` varchar(50) NOT NULL,
  `log_senha` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbl_login`
--

INSERT INTO `tbl_login` (`log_id`, `log_login`, `log_senha`) VALUES
(1, 'zeh', '$2y$10$Lm/g0PCUGL97f6AK.M7HYunZsrF4up0KrKqAUufUIM3NW824bB8sm'),
(2, 'juju', '$2y$10$zvueZeT3iEJgbhLrslj7IeZlAHYMNPr4VnccNvBw9v.m6I.UFjYI2'),
(8, 'juquinha', '$2y$10$JCQSoPxJHS/8jfA/OMNFWOKWAQE/YZAfwnGmYCm75wM2XHIHX5cVW');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_posts`
--

CREATE TABLE `tbl_posts` (
  `pos_id` int(11) NOT NULL,
  `pos_titulo` varchar(250) NOT NULL,
  `pos_subtitulo` varchar(250) NOT NULL,
  `pos_img` varchar(50) NOT NULL,
  `pos_texto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbl_posts`
--

INSERT INTO `tbl_posts` (`pos_id`, `pos_titulo`, `pos_subtitulo`, `pos_img`, `pos_texto`) VALUES
(9, 'Teste 01', 'teste', '2020-12-16-Teste01.png', 'teste'),
(10, 'Teste 02', 'treteteet', '2020-12-16-Teste02.png', 'trwetyertyerte'),
(11, 'Teste 03', 'teste', '2020-12-16-Teste03.png', 'teste');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`log_id`);

--
-- Índices para tabela `tbl_posts`
--
ALTER TABLE `tbl_posts`
  ADD PRIMARY KEY (`pos_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tbl_posts`
--
ALTER TABLE `tbl_posts`
  MODIFY `pos_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
